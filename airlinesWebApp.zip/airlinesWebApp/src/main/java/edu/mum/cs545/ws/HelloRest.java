package edu.mum.cs545.ws;

import java.util.List;

import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
//import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import cs545.airline.dao.AirlineDao;
import cs545.airline.dao.AirplaneDao;
import cs545.airline.dao.AirportDao;
import cs545.airline.dao.FlightDao;
import cs545.airline.model.Airline;
import cs545.airline.model.Airplane;
import cs545.airline.model.Airport;
import cs545.airline.model.Flight;
import cs545.airline.service.AirlineService;
import cs545.airline.service.AirplaneService;
import cs545.airline.service.AirportService;
import cs545.airline.service.FlightService;

@Path("/airlines")
public class HelloRest {
	
	// Not the best way of doing it, but it works for this project
	private AirlineService airlineService = new AirlineService(new AirlineDao());
	private FlightService flightService=new FlightService(new FlightDao());
	private AirportService airportService=new AirportService(new AirportDao());
	private AirplaneService airplaneService=new AirplaneService(new AirplaneDao());
	@GET
	public String helloWorld(@DefaultValue("Gorgeous") @QueryParam("name") String name) {
		return "Hello "+name+"!";
	}
	
	
	//////////////////////test//////////////////////////////////////
	@GET
	@Path("airline")	
	@Produces(MediaType.APPLICATION_XML)
	public User getAirlineTest() {
		
//		String result = "Nil!";
//		List<Airline> airlines = airlineService.findAll();
//		
//		for(Airline airline : airlines) {
//			result = "This is an airline: "+airline.getName();
//		}
		User user=new User();
		user.setName("Sewlesew");
		user.setEmail("yaregal.sewlesew@gmail.com");
		return user;
	}
	
	@POST
    @Consumes({MediaType.APPLICATION_XML})
    @Produces({MediaType.TEXT_PLAIN})
    @Path("/tpost")
    public String postMessage(Airline msg) throws Exception{
        
        System.out.println("First Name = "+msg.getName());     
        
        return "ok";
    }
	
	
//////////////////////////////////for AirLine Service/////////////////////////////////////////////

	@GET
	@Path("all/airlines")	
    @Produces(MediaType.APPLICATION_XML)
	public List<Airline>  getAllAirlines() {		
		String result = "Nil!";
		List<Airline> airlines = airlineService.findAll();		
		for(Airline airline : airlines) {
			result = "This is an airline: "+airline.getName();
		}
		return  airlines ;
	}
	
	@POST
    @Consumes({MediaType.APPLICATION_XML})
    @Produces({MediaType.TEXT_PLAIN})
    @Path("create/airline")
    public String createAirline(Airline airline ) throws Exception{        
		airlineService.create(airline);
        System.out.println("Airline = "+airline.getName()+" is created..!");     
        
        return "ok";
    }
	
	@PUT
    @Path("update/airine")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public String  updateAirline(Airline airline) {
		airlineService.update(airline);
		 System.out.println("Airline = "+airline.getName()+" is updated..!");
		return "ok";
    }
	
	@DELETE
    @Path("/cancel/airline")
    public String deleteAirline(Airline airline) {
		airlineService.delete(airline);
		System.out.println("Airline = "+airline.getName()+" is deleted..!");
		return "ok";
		}
	
	
	///////////////////////////////////	for flight service////////////////////////////////////////////////////////

	@GET
	@Path("all/flights")	
    @Produces(MediaType.APPLICATION_XML)
	public List<Flight>  getAllFlights() {		
		List<Flight> flights = flightService.findAll();	
		return  flights ;
	}
	
	
	@POST
	@Path("create/flight")	
    @Produces(MediaType.APPLICATION_XML)
	public String  createFlight(Flight flight) {		
		flightService.create(flight);
		System.out.println("Flight ="+flight.getId()+ " is created..!");	  
		return  "ok";
	}
	
	@PUT
	@Path("update/flight")	
    @Produces(MediaType.APPLICATION_XML)
	public String  updateFlight(Flight flight) {		
		flightService.update(flight);
		System.out.println("Flight ="+flight.getId()+ " is updated..!");	  
		return  "ok";
	}
	
	@DELETE
	@Path("update/flight")	
    @Produces(MediaType.APPLICATION_XML)
	public String  deleteFlight(Flight flight) {		
		flightService.delete(flight);
		System.out.println("Flight ="+flight.getId()+ " is deleted..!");	  
		return  "ok";
	}
	
	
	
	
//////////////////////////////////////////for Airport service/////////////////////////////////////////////////

	
	@GET
	@Path("all/airports")
	@Produces(MediaType.APPLICATION_XML)
	public List<Airport> getAllAirports(){
		List<Airport> airports=airportService.findAll();
		return airports;
	}
	
	@POST
	@Path("create/airport")
	@Produces(MediaType.APPLICATION_XML)
	public String createAirport(Airport airport){
		airportService.create(airport);
		System.out.println("Airport = "+airport.getName()+" is created!");
		return "ok";
	}
	
	@PUT
	@Path("update/airport")
	@Produces(MediaType.APPLICATION_XML)
	public String updateAirport(Airport airport){
		airportService.update(airport);
		System.out.println("Airport = "+airport.getName()+" is updated.!");
		return "ok";
	}
	
	@DELETE
	@Path("delete/airport")
	@Produces(MediaType.APPLICATION_XML)
	public String deleteAirport(Airport airport){
		airportService.delete(airport);
		System.out.println("Airport = "+airport.getName()+" is deleted.!");
		return "ok";
	}
	
	/////////////////////////////////// Air plane services //////////////////////////////
	
	
	@GET
	@Path("all/airplanes")
	@Produces(MediaType.APPLICATION_XML)
	public List<Airplane> getAllAirplanes(){
		List<Airplane> airplanes=airplaneService.findAll();		
		return airplanes;
	}
	
	
	@POST
	@Path("create/airplane")
	@Produces(MediaType.APPLICATION_XML)
	public String  createAirplane(Airplane airplane){
	airplaneService.create(airplane);
	System.out.println("Airplane = "+airplane.getModel()+ " is created..!");
		return "ok";
	}
	
	@PUT
	@Path("update/airplane")
	@Produces(MediaType.APPLICATION_XML)
	public String  updateAirplane(Airplane airplane){
	airplaneService.update(airplane);
	System.out.println("Airplane = "+airplane.getModel()+ " is updated..!");
		return "ok";
	}
	
	
	@DELETE
	@Path("delete/airplane")
	@Produces(MediaType.APPLICATION_XML)
	public String  deleteAirplane(Airplane airplane){
	airplaneService.delete(airplane);
	System.out.println("Airplane = "+airplane.getModel()+ " is deleted..!");
		return "ok";
	}
	
	
	
	
}
