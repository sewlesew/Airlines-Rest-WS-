
package edu.mum.cs545.app;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import cs545.airline.dao.FlightDao;
import cs545.airline.model.Airline;
import cs545.airline.model.Airport;
import cs545.airline.model.Flight;
import cs545.airline.service.FlightService;

@Named("serviceBean")
@SessionScoped
public class ServiceBean implements Serializable{
	
	private static final long SerialversionUID=1L;
	private FlightService flightservice=new FlightService(new FlightDao());
	private Date departureDate;
	
	private Date destinationDate;
	private Date datetime;
	
	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getDestinationDate() {
		return destinationDate;
	}

	public void setDestinationDate(Date destinationDate) {
		this.destinationDate = destinationDate;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}



//	@Inject	
//	public ServiceBean(FlightService flightservice){
//		this.flightservice=flightservice;
//	}
	
	
	
	public List<Flight> findAll(){
		  List<Flight> flights=flightservice.findAll();		
		  for(Flight f:flights){
			  System.out.println("sssssssssssssssssssssssssssssss"+f.getFlightnr());
		  }
		  
		  return  flights;
	}
	
	public List<Flight> findByDeparture(){
		System.out.println("testttttttttttttt date "+departureDate);
		return flightservice.findByDeparture(departureDate);
	}
	
	public List<Flight> findByDestination(Airport airport){
		return flightservice.findByDestination(airport);
	}
	
	public List<Flight> findByAirLine(Airline airline){
		return flightservice.findByAirline(airline);
	}
	
	
	public List<Flight> findByArrival(){
		return flightservice.findByArrival(datetime);
	}
	

}
